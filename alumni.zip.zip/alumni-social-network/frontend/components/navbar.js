import { getAvatarMarkup } from "../../utils/helpers.js";

export function renderNavbar(currentUser, route) {
  return `
    <header class="navbar">
      <div class="navbar-inner">
        <button class="nav-brand" data-route="/home" type="button">AlumniConnect</button>
        <nav class="nav-links">
          <button class="nav-btn ${route.name === "home" ? "active" : ""}" data-route="/home" type="button">Home</button>
          <button class="nav-btn ${route.name === "directory" ? "active" : ""}" data-route="/directory" type="button">Directory</button>
          <button class="nav-btn ${route.name === "messages" ? "active" : ""}" data-route="/messages" type="button">Messages</button>
          <button class="nav-btn ${route.name === "profile" ? "active" : ""}" data-route="/profile/${currentUser.id}" type="button">Profile</button>
          <button class="nav-btn" data-action="open-post-modal" type="button">Add Post</button>
        </nav>
        <div class="nav-right">
          <button class="nav-avatar-chip" data-route="/profile/${currentUser.id}" type="button">
            ${getAvatarMarkup(currentUser, "avatar avatar-sm")}
          </button>
          <button class="btn btn-ghost btn-sm" data-action="logout" type="button">Logout</button>
        </div>
      </div>
    </header>
  `;
}
