import { renderCommentBox } from "./commentBox.js";
import { escapeHtml, formatRelativeDate, getAvatarMarkup } from "../../utils/helpers.js";

export function renderPostCard(post, currentUser) {
  const liked = Boolean(post.likedByCurrentUser);
  const commentsCount = (post.comments || []).length;

  return `
    <article class="card post-card">
      <div class="post-header">
        ${getAvatarMarkup(post.user, "avatar avatar-md")}
        <div class="post-meta">
          <strong>${escapeHtml(post.user?.full_name || "Alumni")}</strong>
          <span>${escapeHtml(post.user?.department || "Alumni")} � ${formatRelativeDate(post.created_at)}</span>
        </div>
        ${
          String(post.user_id) === String(currentUser.id)
            ? `<button class="action-btn delete-btn" data-action="delete-post" data-id="${post.id}" type="button">Delete</button>`
            : `<button class="action-btn" data-action="open-profile" data-user-id="${post.user?.id}" type="button">View</button>`
        }
      </div>
      ${post.text ? `<p class="post-text">${escapeHtml(post.text)}</p>` : ""}
      ${post.image_url ? `<img class="post-image" src="${escapeHtml(post.image_url)}" alt="Post media" />` : ""}
      <div class="post-actions">
        <button class="action-btn ${liked ? "liked" : ""}" data-action="toggle-like" data-id="${post.id}" type="button">
          ? ${post.likesCount} Like${post.likesCount === 1 ? "" : "s"}
        </button>
        <span class="action-btn static-action">${commentsCount} Comment${commentsCount === 1 ? "" : "s"}</span>
      </div>
      ${renderCommentBox(post, currentUser)}
    </article>
  `;
}
