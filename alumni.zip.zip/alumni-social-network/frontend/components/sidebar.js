export function renderSidebar() {
  return "";
}
