export function renderLoginPage() {
  return `
    <section class="auth-shell auth-centered">
      <div class="auth-box card">
        <div class="auth-header">
          <h1>AlumniConnect</h1>
          <p>Stay connected with your alma mater</p>
        </div>
        <div class="auth-tabs-shell">
          <button class="auth-tab active" type="button">Sign In</button>
          <button class="auth-tab" data-route="/signup" type="button">Sign Up</button>
        </div>
        <form data-form="login" class="auth-form">
          <div class="field">
            <label>Email</label>
            <input class="input" name="email" type="email" placeholder="you@university.edu" required />
          </div>
          <div class="field">
            <label>Password</label>
            <input class="input" name="password" type="password" placeholder="��������" required />
          </div>
          <button class="btn btn-primary btn-full" type="submit">Sign In</button>
          <p class="text-muted centered-text">Don't have an account? <button class="text-link" data-route="/signup" type="button">Sign Up</button></p>
        </form>
      </div>
    </section>
  `;
}
