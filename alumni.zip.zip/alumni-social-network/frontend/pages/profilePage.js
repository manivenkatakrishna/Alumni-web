import { escapeHtml, getAvatarMarkup } from "../../utils/helpers.js";

function renderPosts(posts = [], currentUserId) {
  if (!posts.length) {
    return `<div class="empty-state card"><p>No posts yet. Share something!</p></div>`;
  }

  return posts
    .map(
      (post) => `
        <article class="card profile-post-card">
          ${post.image_url ? `<img class="profile-post-image" src="${escapeHtml(post.image_url)}" alt="Profile post" />` : ""}
          <div class="profile-post-copy ${post.image_url ? "with-image" : ""}">
            ${post.text ? `<p>${escapeHtml(post.text)}</p>` : `<p class="text-muted">Media post</p>`}
            ${String(post.user_id) === String(currentUserId) ? `<button class="btn btn-danger btn-sm" data-action="delete-post" data-id="${post.id}" type="button">Delete</button>` : ""}
          </div>
        </article>
      `,
    )
    .join("");
}

export function renderProfilePage(profile, currentUser) {
  const user = profile?.user || currentUser;
  return `
    <section class="profile-page-modern">
      <div class="card profile-shell">
        <div class="profile-cover"></div>
        <div class="profile-info">
          <div class="profile-avatar-row">
            <div class="profile-id-block">
              ${getAvatarMarkup(user, "avatar avatar-xl avatar-ring")}
              <div>
                <div class="profile-name">${escapeHtml(user.full_name || "Alumni")}</div>
                <div class="profile-dept">${escapeHtml(user.department || "Alumni")} ${user.graduation_year ? `� Class of ${escapeHtml(user.graduation_year)}` : ""}</div>
                ${user.company ? `<div class="job-line">${escapeHtml(user.company)}</div>` : ""}
              </div>
            </div>
            ${profile?.isOwner ? `<button class="btn btn-outline" data-action="open-profile-edit" type="button">Edit Profile</button>` : `<button class="btn btn-primary" data-action="open-message-thread" data-user-id="${user.id}" type="button">Send Message</button>`}
          </div>
          ${user.bio ? `<p class="profile-bio">${escapeHtml(user.bio)}</p>` : ""}
          <div class="profile-inline-meta">
            ${user.location ? `<span>?? ${escapeHtml(user.location)}</span>` : ""}
            ${user.email ? `<span>?? ${escapeHtml(user.email)}</span>` : ""}
          </div>
          <div class="profile-stats">
            <div class="stat"><div class="num">${profile?.posts?.length || 0}</div><div class="lbl">Posts</div></div>
            <div class="stat"><div class="num">${profile?.connectionsCount || 0}</div><div class="lbl">Connections</div></div>
            <div class="stat"><div class="num">${escapeHtml(user.graduation_year || "�")}</div><div class="lbl">Grad Year</div></div>
          </div>
          ${user.department ? `<div class="profile-tags"><span class="tag">${escapeHtml(user.department)}</span></div>` : ""}
        </div>
      </div>
      <div class="section-title">${profile?.isOwner ? "My Posts" : "Posts"}</div>
      <div class="profile-posts-stack">${renderPosts(profile?.posts || [], currentUser.id)}</div>
    </section>
  `;
}
