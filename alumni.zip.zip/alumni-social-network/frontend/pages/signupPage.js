export function renderSignupPage() {
  return `
    <section class="auth-shell auth-centered">
      <div class="auth-box card">
        <div class="auth-header">
          <h1>AlumniConnect</h1>
          <p>Create your alumni profile</p>
        </div>
        <div class="auth-tabs-shell">
          <button class="auth-tab" data-route="/login" type="button">Sign In</button>
          <button class="auth-tab active" type="button">Sign Up</button>
        </div>
        <form data-form="signup" class="auth-form">
          <div class="field">
            <label>Full Name</label>
            <input class="input" name="full_name" placeholder="Jane Doe" required />
          </div>
          <div class="field">
            <label>Email</label>
            <input class="input" name="email" type="email" placeholder="jane@university.edu" required />
          </div>
          <div class="field">
            <label>Password</label>
            <input class="input" name="password" type="password" placeholder="Min 6 characters" required />
          </div>
          <div class="field">
            <label>Department</label>
            <input class="input" name="department" placeholder="Computer Science" required />
          </div>
          <div class="field">
            <label>Graduation Year</label>
            <input class="input" name="graduation_year" type="number" placeholder="2020" required />
          </div>
          <div class="field">
            <label>Profile Photo</label>
            <input class="input" name="profile_image" type="file" accept="image/*" data-preview-target="signup-preview" />
            <div class="image-preview" id="signup-preview"></div>
          </div>
          <div class="field">
            <label>Bio</label>
            <textarea class="input" name="bio" rows="3" placeholder="Tell us about yourself..."></textarea>
          </div>
          <div class="field">
            <label>Location</label>
            <input class="input" name="location" placeholder="City, Country" />
          </div>
          <div class="field">
            <label>Current Job</label>
            <input class="input" name="company" placeholder="Software Engineer @ Company" />
          </div>
          <button class="btn btn-primary btn-full" type="submit">Create Account</button>
        </form>
      </div>
    </section>
  `;
}
