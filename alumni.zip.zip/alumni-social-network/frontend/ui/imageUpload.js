import { getStorageBucket, supabase } from "../../supabase.js";
import { escapeHtml } from "../../utils/helpers.js";

export async function uploadFile(file, folder) {
  const bucket = getStorageBucket(folder);
  const fileExt = file.name.split(".").pop();
  const objectPath = `${folder}/${Date.now()}-${Math.random().toString(36).slice(2)}.${fileExt}`;
  const { error } = await supabase.storage.from(bucket).upload(objectPath, file, {
    cacheControl: "3600",
    upsert: false,
  });

  if (error) {
    throw new Error(`Upload failed for bucket "${bucket}": ${error.message}`);
  }

  const { data } = supabase.storage.from(bucket).getPublicUrl(objectPath);
  return data.publicUrl;
}

export function renderImagePreview(input) {
  const targetId = input.dataset.previewTarget;
  const preview = document.getElementById(targetId);
  if (!preview) {
    return;
  }

  preview.innerHTML = "";
  const file = input.files?.[0];
  if (!file) {
    return;
  }

  const url = URL.createObjectURL(file);
  const isVideo = file.type.startsWith("video/");

  preview.innerHTML = isVideo
    ? `<video controls src="${escapeHtml(url)}"></video>`
    : `<img src="${escapeHtml(url)}" alt="Preview" />`;
}
